import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Bell, Bookmark, Camera, Check, ChevronLeft, Heart, Home, Image as ImageIcon,
  MessageCircle, MoreHorizontal, Search, Send, Settings, Share2, Smile, User,
  Users, X, Plus, Menu
} from "lucide-react";
import "./styles.css";

const demoPosts = [
  {
    id: 1, name: "Sarah Johnson", handle: "@sarahj", time: "2h",
    avatar: "https://i.pravatar.cc/120?img=47",
    text: "Beautiful day to slow down, enjoy the little things, and smile. ☀️",
    image: "https://images.unsplash.com/photo-1500534623283-312aade485b7?auto=format&fit=crop&w=1000&q=80",
    likes: 124, comments: 23, liked: false
  },
  {
    id: 2, name: "Michael Carter", handle: "@mcarter", time: "5h",
    avatar: "https://i.pravatar.cc/120?img=12",
    text: "Working on something exciting. More to come soon! 🚀",
    image: null, likes: 76, comments: 11, liked: true
  },
  {
    id: 3, name: "Ava Williams", handle: "@avaw", time: "Yesterday",
    avatar: "https://i.pravatar.cc/120?img=32",
    text: "Good people, good food, good memories. ❤️",
    image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&w=1000&q=80",
    likes: 201, comments: 39, liked: false
  }
];

function tgUser() {
  const u = window.Telegram?.WebApp?.initDataUnsafe?.user;
  return u || { first_name: "You", username: "telegram_user", photo_url: "https://i.pravatar.cc/120?img=5" };
}

function App() {
  const [tab, setTab] = useState("home");
  const [posts, setPosts] = useState(demoPosts);
  const [composer, setComposer] = useState("");
  const [search, setSearch] = useState("");
  const [selectedPost, setSelectedPost] = useState(null);
  const [comment, setComment] = useState("");
  const user = useMemo(tgUser, []);

  React.useEffect(() => {
    const webApp = window.Telegram?.WebApp;
    if (webApp) {
      webApp.ready();
      webApp.expand();
      webApp.setHeaderColor?.("#f5f7fb");
      webApp.setBackgroundColor?.("#f5f7fb");
    }
  }, []);

  function publish() {
    const text = composer.trim();
    if (!text) return;
    setPosts(p => [{
      id: Date.now(), name: `${user.first_name || "You"} ${user.last_name || ""}`.trim(),
      handle: user.username ? `@${user.username}` : "@telegram_user",
      time: "now", avatar: user.photo_url || "https://i.pravatar.cc/120?img=5",
      text, image: null, likes: 0, comments: 0, liked: false
    }, ...p]);
    setComposer("");
  }

  function toggleLike(id) {
    setPosts(p => p.map(x => x.id === id ? {...x, liked: !x.liked, likes: x.likes + (x.liked ? -1 : 1)} : x));
  }

  function sendComment() {
    if (!comment.trim() || !selectedPost) return;
    setPosts(p => p.map(x => x.id === selectedPost.id ? {...x, comments: x.comments + 1} : x));
    setComment("");
  }

  const filtered = posts.filter(p => `${p.name} ${p.handle} ${p.text}`.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="app">
      <header className="topbar">
        <button className="icon-btn"><Menu size={22}/></button>
        <div className="brand">MySocial</div>
        <div className="top-actions">
          <button className="icon-btn" onClick={() => setTab("search")}><Search size={21}/></button>
          <button className="icon-btn" onClick={() => setTab("notifications")}><Bell size={21}/><span className="dot"/></button>
        </div>
      </header>

      <main className="content">
        {tab === "home" && <>
          <section className="stories">
            <div className="story add-story"><div className="story-avatar add"><Plus size={20}/></div><span>Your story</span></div>
            {["Mia","Daniel","Olivia","Noah"].map((n,i)=>
              <div className="story" key={n}><img src={`https://i.pravatar.cc/120?img=${20+i}`} /><span>{n}</span></div>
            )}
          </section>

          <section className="composer card">
            <div className="composer-row">
              <img className="avatar" src={user.photo_url || "https://i.pravatar.cc/120?img=5"} />
              <textarea value={composer} onChange={e=>setComposer(e.target.value)} placeholder="What's on your mind?" />
            </div>
            <div className="composer-actions">
              <button><ImageIcon size={18}/> Photo</button>
              <button><Smile size={18}/> Feeling</button>
              <button className="post-btn" onClick={publish}>Post</button>
            </div>
          </section>

          {filtered.map(post => <Post key={post.id} post={post} onLike={()=>toggleLike(post.id)} onComment={()=>setSelectedPost(post)} />)}
        </>}

        {tab === "search" && <SearchPage value={search} setValue={setSearch} posts={posts} onComment={setSelectedPost}/>}
        {tab === "notifications" && <Notifications/>}
        {tab === "profile" && <Profile user={user} posts={posts}/>}
        {tab === "friends" && <Friends/>}
      </main>

      <nav className="bottom-nav">
        <NavButton active={tab==="home"} icon={<Home/>} label="Home" onClick={()=>setTab("home")}/>
        <NavButton active={tab==="friends"} icon={<Users/>} label="Friends" onClick={()=>setTab("friends")}/>
        <button className="create-fab" onClick={()=>{setTab("home"); document.querySelector("textarea")?.focus()}}><Plus/></button>
        <NavButton active={tab==="notifications"} icon={<Bell/>} label="Alerts" onClick={()=>setTab("notifications")}/>
        <NavButton active={tab==="profile"} icon={<User/>} label="Profile" onClick={()=>setTab("profile")}/>
      </nav>

      {selectedPost && <div className="modal-backdrop" onClick={()=>setSelectedPost(null)}>
        <div className="comments-sheet" onClick={e=>e.stopPropagation()}>
          <div className="sheet-head"><strong>Comments</strong><button className="icon-btn" onClick={()=>setSelectedPost(null)}><X/></button></div>
          <div className="comment-placeholder">Join the conversation about {selectedPost.name}'s post.</div>
          <div className="comment-box"><input value={comment} onChange={e=>setComment(e.target.value)} placeholder="Write a comment..." onKeyDown={e=>e.key==="Enter"&&sendComment()}/><button onClick={sendComment}><Send size={18}/></button></div>
        </div>
      </div>}
    </div>
  );
}

function Post({post,onLike,onComment}) {
  return <article className="card post">
    <div className="post-head">
      <img className="avatar" src={post.avatar}/>
      <div className="post-meta"><strong>{post.name} <Check className="verified" size={13}/></strong><span>{post.handle} · {post.time}</span></div>
      <button className="icon-btn"><MoreHorizontal/></button>
    </div>
    <p className="post-text">{post.text}</p>
    {post.image && <img className="post-image" src={post.image}/>}
    <div className="engagement"><span>{post.likes ? `❤️ ${post.likes}` : ""}</span><span>{post.comments} comments</span></div>
    <div className="post-actions">
      <button className={post.liked ? "liked" : ""} onClick={onLike}><Heart size={19} fill={post.liked ? "currentColor":"none"}/> Like</button>
      <button onClick={onComment}><MessageCircle size={19}/> Comment</button>
      <button><Share2 size={19}/> Share</button>
      <button><Bookmark size={18}/></button>
    </div>
  </article>
}

function NavButton({active,icon,label,onClick}) {
  return <button className={`nav-btn ${active?"active":""}`} onClick={onClick}>{React.cloneElement(icon,{size:21})}<span>{label}</span></button>
}
function SearchPage({value,setValue,posts,onComment}) {
  const results=posts.filter(p=>`${p.name} ${p.text}`.toLowerCase().includes(value.toLowerCase()));
  return <><div className="page-title">Search</div><div className="searchbox"><Search size={19}/><input autoFocus value={value} onChange={e=>setValue(e.target.value)} placeholder="Search people or posts"/></div>{results.map(p=><Post key={p.id} post={p} onLike={()=>{}} onComment={()=>onComment(p)}/>)}</>
}
function Notifications(){return <><div className="page-title">Notifications</div>{["Sarah liked your post","Michael commented on your post","Ava started following you"].map((x,i)=><div className="notification card" key={x}><img className="avatar" src={`https://i.pravatar.cc/120?img=${40+i}`}/><div><strong>{x}</strong><span>{i+1}h ago</span></div><Heart size={18}/></div>)}</>}
function Profile({user,posts}){return <><div className="profile card"><img className="profile-cover" src="https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1200&q=80"/><img className="profile-avatar" src={user.photo_url || "https://i.pravatar.cc/120?img=5"}/><div className="profile-body"><h2>{user.first_name || "You"} {user.last_name || ""}</h2><p>@{user.username || "telegram_user"}</p><p>Building connections and sharing moments. ✨</p><div className="stats"><b>{posts.length}<small> Posts</small></b><b>248<small> Followers</small></b><b>186<small> Following</small></b></div></div></div>{posts.slice(0,2).map(p=><Post key={p.id} post={p} onLike={()=>{}} onComment={()=>{}}/>)}</>}
function Friends(){return <><div className="page-title">Friends</div>{["Emma Wilson","James Brown","Sophia Lee","Liam Davis"].map((n,i)=><div className="friend card" key={n}><img className="avatar" src={`https://i.pravatar.cc/120?img=${50+i}`}/><div><strong>{n}</strong><span>12 mutual friends</span></div><button className="follow">Add</button></div>)}</>}

createRoot(document.getElementById("root")).render(<App/>);